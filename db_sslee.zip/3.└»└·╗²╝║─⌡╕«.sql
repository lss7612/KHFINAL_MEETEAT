INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
VALUES(tb_user2_seq.nextval, 'adminid', 'adminpw', '����������', 'm', '20-29', 0,'admin@meeteat.com',null, 0);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
VALUES(tb_user2_seq.nextval, 'payid', 'paypw', '��������', 'f', '20-29', 0,'pay@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
VALUES(tb_user2_seq.nextval, 'commonid', 'commonpw', '�Ϲ�����', 'm', '20-29', 0,'common@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
VALUES(tb_user2_seq.nextval, 'banid', 'banpw', '������������', 'f', '20-29', 0,'ban@meeteat.com',null, 3);





INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid4', 'adminpw4', '������', 'f', '20-29', 0,'user4@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid5', 'adminpw5', '������', 'm', '20-29', 0,'user5@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid6', 'adminpw6', '�ɼ���', 'f', '20-29', 0,'user6@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid7', 'adminpw7', '������', 'f', '20-29', 0,'user7@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid8', 'adminpw8', '������', 'f', '20-29', 0,'user8@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid9', 'adminpw9', '������', 'f', '20-29', 0,'user9@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid10', 'adminpw10', '������', 'f', '20-29', 0,'user10@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid11', 'adminpw11', '������', 'f', '20-29', 0,'user11@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid12', 'adminpw12', '�۽���', 'f', '20-29', 0,'user12@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid13', 'adminpw13', '�ӹμ�', 'f', '20-29', 0,'user13@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid14', 'adminpw14', '���̾�', 'm', '20-29', 0,'user14@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid15', 'adminpw15', '���̾�', 'm', '20-29', 0,'user15@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid16', 'adminpw16', '���ο�', 'm', '20-29', 0,'user16@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid17', 'adminpw17', '������', 'f', '20-29', 0,'user17@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid18', 'adminpw18', '���ؼ�', 'm', '20-29', 0,'user18@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid19', 'adminpw19', '������', 'f', '20-29', 0,'user19@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid20', 'adminpw20', '������', 'f', '20-29', 0,'user20@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid21', 'adminpw21', '�Ű���', 'f', '20-29', 0,'user21@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid22', 'adminpw22', '�ɽ¹�', 'f', '20-29', 0,'user22@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid23', 'adminpw23', '������', 'f', '20-29', 0,'user23@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid24', 'adminpw24', '����ȣ', 'f', '20-29', 0,'user24@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid25', 'adminpw25', '������', 'f', '20-29', 0,'user25@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid26', 'adminpw26', '���ؼ�', 'm', '20-29', 0,'user26@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid27', 'adminpw27', '�Žÿ�', 'f', '20-29', 0,'user27@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid28', 'adminpw28', '����ȯ', 'm', '20-29', 0,'user28@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid29', 'adminpw29', '���μ�', 'f', '20-29', 0,'user29@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid30', 'adminpw30', '���ؼ�', 'm', '20-29', 0,'user30@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid31', 'adminpw31', '������', 'f', '20-29', 0,'user31@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid32', 'adminpw32', '�ѱԹ�', 'f', '20-29', 0,'user32@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid33', 'adminpw33', '������', 'm', '20-29', 0,'user33@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid34', 'adminpw34', '������', 'f', '20-29', 0,'user34@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid35', 'adminpw35', '������', 'f', '20-29', 0,'user35@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid36', 'adminpw36', '���ؼ�', 'm', '20-29', 0,'user36@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid37', 'adminpw37', '������', 'm', '20-29', 0,'user37@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid38', 'adminpw38', '������', 'm', '20-29', 0,'user38@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid39', 'adminpw39', '������', 'm', '20-29', 0,'user39@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid40', 'adminpw40', '���ֿ�', 'f', '20-29', 0,'user40@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid41', 'adminpw41', '������', 'f', '20-29', 0,'user41@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid42', 'adminpw42', '������', 'm', '20-29', 0,'user42@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid43', 'adminpw43', '���ؼ�', 'm', '20-29', 0,'user43@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid44', 'adminpw44', '������', 'm', '20-29', 0,'user44@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid45', 'adminpw45', '���̾�', 'f', '20-29', 0,'user45@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid46', 'adminpw46', '������', 'f', '20-29', 0,'user46@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid47', 'adminpw47', '������', 'f', '20-29', 0,'user47@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid48', 'adminpw48', 'Ȳ����', 'f', '20-29', 0,'user48@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid49', 'adminpw49', '������', 'f', '20-29', 0,'user49@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid50', 'adminpw50', '�����', 'f', '20-29', 0,'user50@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid51', 'adminpw51', '���¾�', 'm', '20-29', 0,'user51@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid52', 'adminpw52', '���ؿ�', 'f', '20-29', 0,'user52@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid53', 'adminpw53', '������', 'f', '20-29', 0,'user53@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid54', 'adminpw54', '������', 'm', '20-29', 0,'user54@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid55', 'adminpw55', '������', 'm', '20-29', 0,'user55@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid56', 'adminpw56', '������', 'f', '20-29', 0,'user56@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid57', 'adminpw57', '������', 'm', '20-29', 0,'user57@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid58', 'adminpw58', '������', 'f', '20-29', 0,'user58@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid59', 'adminpw59', '����', 'm', '20-29', 0,'user59@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid60', 'adminpw60', '������', 'f', '20-29', 0,'user60@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid61', 'adminpw61', '������', 'm', '20-29', 0,'user61@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid62', 'adminpw62', '�����', 'm', '20-29', 0,'user62@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid63', 'adminpw63', '������', 'f', '20-29', 0,'user63@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid64', 'adminpw64', '����ȣ', 'm', '20-29', 0,'user64@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid65', 'adminpw65', '�Ѽ���', 'f', '20-29', 0,'user65@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid66', 'adminpw66', '������', 'm', '20-29', 0,'user66@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid67', 'adminpw67', '������', 'm', '20-29', 0,'user67@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid68', 'adminpw68', '������', 'f', '20-29', 0,'user68@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid69', 'adminpw69', '������', 'm', '20-29', 0,'user69@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid70', 'adminpw70', 'Ȳ����', 'f', '20-29', 0,'user70@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid71', 'adminpw71', '���ؼ�', 'f', '20-29', 0,'user71@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid72', 'adminpw72', '������', 'f', '20-29', 0,'user72@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid73', 'adminpw73', '������', 'f', '20-29', 0,'user73@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid74', 'adminpw74', '������', 'f', '20-29', 0,'user74@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid75', 'adminpw75', '������', 'm', '20-29', 0,'user75@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid76', 'adminpw76', '���μ�', 'f', '20-29', 0,'user76@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid77', 'adminpw77', '���ֿ�', 'm', '20-29', 0,'user77@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid78', 'adminpw78', '������', 'f', '20-29', 0,'user78@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid79', 'adminpw79', '����ȣ', 'f', '20-29', 0,'user79@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid80', 'adminpw80', '����ȣ', 'm', '20-29', 0,'user80@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid81', 'adminpw81', '������', 'f', '20-29', 0,'user81@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid82', 'adminpw82', '���Թ�', 'm', '20-29', 0,'user82@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid83', 'adminpw83', '�輺��', 'f', '20-29', 0,'user83@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid84', 'adminpw84', '������', 'f', '20-29', 0,'user84@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid85', 'adminpw85', '������', 'f', '20-29', 0,'user85@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid86', 'adminpw86', '������', 'm', '20-29', 0,'user86@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid87', 'adminpw87', '���α�', 'm', '20-29', 0,'user87@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid88', 'adminpw88', '�����', 'm', '20-29', 0,'user88@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid89', 'adminpw89', '����', 'm', '20-29', 0,'user89@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid90', 'adminpw90', '�۽ÿ�', 'f', '20-29', 0,'user90@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid91', 'adminpw91', '������', 'm', '20-29', 0,'user91@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid92', 'adminpw92', '������', 'm', '20-29', 0,'user92@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid93', 'adminpw93', '���¹�', 'm', '20-29', 0,'user93@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid94', 'adminpw94', '������', 'm', '20-29', 0,'user94@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid95', 'adminpw95', '���ؼ�', 'f', '20-29', 0,'user95@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid96', 'adminpw96', '������', 'm', '20-29', 0,'user96@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid97', 'adminpw97', '���μ�', 'm', '20-29', 0,'user97@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid98', 'adminpw98', '������', 'f', '20-29', 0,'user98@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid99', 'adminpw99', '�����', 'm', '20-29', 0,'user99@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid100', 'adminpw100', '������', 'm', '20-29', 0,'user100@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid101', 'adminpw101', '�ڿ��', 'm', '20-29', 0,'user101@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid102', 'adminpw102', '���¹�', 'f', '20-29', 0,'user102@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid103', 'adminpw103', '����ȣ', 'f', '20-29', 0,'user103@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid104', 'adminpw104', '������', 'f', '20-29', 0,'user104@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid105', 'adminpw105', '���ÿ�', 'f', '20-29', 0,'user105@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid106', 'adminpw106', '���ؼ�', 'f', '20-29', 0,'user106@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid107', 'adminpw107', '�ż���', 'f', '20-29', 0,'user107@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid108', 'adminpw108', '������', 'm', '20-29', 0,'user108@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid109', 'adminpw109', '������', 'm', '20-29', 0,'user109@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid110', 'adminpw110', '������', 'm', '20-29', 0,'user110@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid111', 'adminpw111', '���ؼ�', 'f', '20-29', 0,'user111@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid112', 'adminpw112', '�ڼ���', 'f', '20-29', 0,'user112@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid113', 'adminpw113', '�۽���', 'f', '20-29', 0,'user113@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid114', 'adminpw114', 'Ȳ����', 'm', '20-29', 0,'user114@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid115', 'adminpw115', '������', 'm', '20-29', 0,'user115@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid116', 'adminpw116', '�强��', 'm', '20-29', 0,'user116@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid117', 'adminpw117', '������', 'm', '20-29', 0,'user117@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid118', 'adminpw118', '�ѹο�', 'f', '20-29', 0,'user118@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid119', 'adminpw119', '������', 'f', '20-29', 0,'user119@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid120', 'adminpw120', '������', 'f', '20-29', 0,'user120@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid121', 'adminpw121', '�ѽÿ�', 'm', '20-29', 0,'user121@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid122', 'adminpw122', '������', 'f', '20-29', 0,'user122@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid123', 'adminpw123', '������', 'm', '20-29', 0,'user123@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid124', 'adminpw124', '������', 'm', '20-29', 0,'user124@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid125', 'adminpw125', '������', 'f', '20-29', 0,'user125@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid126', 'adminpw126', '�ڼ�ȣ', 'f', '20-29', 0,'user126@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid127', 'adminpw127', '���ο�', 'm', '20-29', 0,'user127@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid128', 'adminpw128', '������', 'm', '20-29', 0,'user128@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid129', 'adminpw129', '������', 'm', '20-29', 0,'user129@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid130', 'adminpw130', '�缺��', 'f', '20-29', 0,'user130@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid131', 'adminpw131', '�ֹ���', 'm', '20-29', 0,'user131@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid132', 'adminpw132', '������', 'f', '20-29', 0,'user132@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid133', 'adminpw133', '������', 'f', '20-29', 0,'user133@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid134', 'adminpw134', '����ȣ', 'm', '20-29', 0,'user134@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid135', 'adminpw135', '������', 'm', '20-29', 0,'user135@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid136', 'adminpw136', '���Ѱ�', 'f', '20-29', 0,'user136@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid137', 'adminpw137', '���¿�', 'f', '20-29', 0,'user137@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid138', 'adminpw138', '���¹�', 'm', '20-29', 0,'user138@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid139', 'adminpw139', '���ǿ�', 'f', '20-29', 0,'user139@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid140', 'adminpw140', '������', 'f', '20-29', 0,'user140@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid141', 'adminpw141', '������', 'm', '20-29', 0,'user141@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid142', 'adminpw142', '���ؿ�', 'm', '20-29', 0,'user142@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid143', 'adminpw143', '�ѽ¿�', 'f', '20-29', 0,'user143@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid144', 'adminpw144', '���ؿ�', 'f', '20-29', 0,'user144@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid145', 'adminpw145', '������', 'f', '20-29', 0,'user145@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid146', 'adminpw146', '������', 'f', '20-29', 0,'user146@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid147', 'adminpw147', '�ֹ���', 'm', '20-29', 0,'user147@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid148', 'adminpw148', '���¾�', 'f', '20-29', 0,'user148@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid149', 'adminpw149', '������', 'm', '20-29', 0,'user149@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid150', 'adminpw150', '������', 'f', '20-29', 0,'user150@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid151', 'adminpw151', '������', 'm', '20-29', 0,'user151@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid152', 'adminpw152', '����ȯ', 'm', '20-29', 0,'user152@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid153', 'adminpw153', '���ؿ�', 'f', '20-29', 0,'user153@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid154', 'adminpw154', '������', 'm', '20-29', 0,'user154@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid155', 'adminpw155', '������', 'f', '20-29', 0,'user155@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid156', 'adminpw156', '�����', 'm', '20-29', 0,'user156@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid157', 'adminpw157', '���¾�', 'm', '20-29', 0,'user157@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid158', 'adminpw158', '������', 'm', '20-29', 0,'user158@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid159', 'adminpw159', '������', 'f', '20-29', 0,'user159@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid160', 'adminpw160', '����ȣ', 'm', '20-29', 0,'user160@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid161', 'adminpw161', '������', 'm', '20-29', 0,'user161@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid162', 'adminpw162', '������', 'm', '20-29', 0,'user162@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid163', 'adminpw163', '��Թ�', 'f', '20-29', 0,'user163@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid164', 'adminpw164', '������', 'm', '20-29', 0,'user164@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid165', 'adminpw165', '������', 'm', '20-29', 0,'user165@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid166', 'adminpw166', '������', 'm', '20-29', 0,'user166@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid167', 'adminpw167', 'Ȳ����', 'm', '20-29', 0,'user167@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid168', 'adminpw168', '�ν���', 'm', '20-29', 0,'user168@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid169', 'adminpw169', '������', 'f', '20-29', 0,'user169@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid170', 'adminpw170', '������', 'f', '20-29', 0,'user170@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid171', 'adminpw171', '���Ϲ�', 'm', '20-29', 0,'user171@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid172', 'adminpw172', '�չ�ȣ', 'f', '20-29', 0,'user172@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid173', 'adminpw173', '������', 'f', '20-29', 0,'user173@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid174', 'adminpw174', '������', 'f', '20-29', 0,'user174@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid175', 'adminpw175', '��μ�', 'm', '20-29', 0,'user175@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid176', 'adminpw176', '�ȼ���', 'm', '20-29', 0,'user176@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid177', 'adminpw177', 'Ȳ����', 'm', '20-29', 0,'user177@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid178', 'adminpw178', '������', 'm', '20-29', 0,'user178@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid179', 'adminpw179', '������', 'm', '20-29', 0,'user179@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid180', 'adminpw180', '���¾�', 'f', '20-29', 0,'user180@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid181', 'adminpw181', '����ȯ', 'm', '20-29', 0,'user181@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid182', 'adminpw182', '����ȣ', 'f', '20-29', 0,'user182@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid183', 'adminpw183', '���α�', 'm', '20-29', 0,'user183@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid184', 'adminpw184', '���Ѱ�', 'f', '20-29', 0,'user184@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid185', 'adminpw185', '������', 'm', '20-29', 0,'user185@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid186', 'adminpw186', '���ؿ�', 'f', '20-29', 0,'user186@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid187', 'adminpw187', '����ȣ', 'm', '20-29', 0,'user187@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid188', 'adminpw188', '���ǿ�', 'm', '20-29', 0,'user188@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid189', 'adminpw189', '�ο���', 'm', '20-29', 0,'user189@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid190', 'adminpw190', '���ο�', 'f', '20-29', 0,'user190@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid191', 'adminpw191', '������', 'm', '20-29', 0,'user191@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid192', 'adminpw192', '������', 'm', '20-29', 0,'user192@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid193', 'adminpw193', '������', 'm', '20-29', 0,'user193@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid194', 'adminpw194', '������', 'f', '20-29', 0,'user194@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid195', 'adminpw195', '������', 'm', '20-29', 0,'user195@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid196', 'adminpw196', '������', 'm', '20-29', 0,'user196@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid197', 'adminpw197', '������', 'f', '20-29', 0,'user197@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid198', 'adminpw198', '������', 'f', '20-29', 0,'user198@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid199', 'adminpw199', '�����', 'm', '20-29', 0,'user199@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid200', 'adminpw200', '������', 'f', '20-29', 0,'user200@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid201', 'adminpw201', '������', 'f', '20-29', 0,'user201@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid202', 'adminpw202', '������', 'f', '20-29', 0,'user202@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid203', 'adminpw203', '����ȣ', 'm', '20-29', 0,'user203@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid204', 'adminpw204', '�㵵��', 'f', '20-29', 0,'user204@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid205', 'adminpw205', '���Թ�', 'm', '20-29', 0,'user205@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid206', 'adminpw206', '���ֿ�', 'f', '20-29', 0,'user206@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid207', 'adminpw207', '�ѿ���', 'm', '20-29', 0,'user207@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid208', 'adminpw208', 'Ȳ����', 'f', '20-29', 0,'user208@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid209', 'adminpw209', '������', 'm', '20-29', 0,'user209@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid210', 'adminpw210', '������', 'f', '20-29', 0,'user210@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid211', 'adminpw211', '������', 'm', '20-29', 0,'user211@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid212', 'adminpw212', '������', 'm', '20-29', 0,'user212@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid213', 'adminpw213', '������', 'm', '20-29', 0,'user213@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid214', 'adminpw214', '������', 'm', '20-29', 0,'user214@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid215', 'adminpw215', '������', 'm', '20-29', 0,'user215@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid216', 'adminpw216', '���Ϲ�', 'f', '20-29', 0,'user216@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid217', 'adminpw217', '������', 'f', '20-29', 0,'user217@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid218', 'adminpw218', '������', 'f', '20-29', 0,'user218@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid219', 'adminpw219', '����', 'f', '20-29', 0,'user219@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid220', 'adminpw220', '���¹�', 'm', '20-29', 0,'user220@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid221', 'adminpw221', '�ֹμ�', 'f', '20-29', 0,'user221@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid222', 'adminpw222', '�ѽ���', 'm', '20-29', 0,'user222@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid223', 'adminpw223', '���϶�', 'f', '20-29', 0,'user223@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid224', 'adminpw224', '������', 'f', '20-29', 0,'user224@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid225', 'adminpw225', '������', 'm', '20-29', 0,'user225@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid226', 'adminpw226', '���¹�', 'm', '20-29', 0,'user226@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid227', 'adminpw227', '�����', 'm', '20-29', 0,'user227@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid228', 'adminpw228', '�μ���', 'm', '20-29', 0,'user228@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid229', 'adminpw229', '������', 'f', '20-29', 0,'user229@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid230', 'adminpw230', '�谭��', 'm', '20-29', 0,'user230@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid231', 'adminpw231', '���Ϲ�', 'm', '20-29', 0,'user231@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid232', 'adminpw232', '������', 'm', '20-29', 0,'user232@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid233', 'adminpw233', '�强��', 'f', '20-29', 0,'user233@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid234', 'adminpw234', '������', 'm', '20-29', 0,'user234@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid235', 'adminpw235', '���Ѱ�', 'm', '20-29', 0,'user235@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid236', 'adminpw236', '���ؼ�', 'm', '20-29', 0,'user236@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid237', 'adminpw237', '���μ�', 'm', '20-29', 0,'user237@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid238', 'adminpw238', '������', 'f', '20-29', 0,'user238@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid239', 'adminpw239', '�ſ���', 'f', '20-29', 0,'user239@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid240', 'adminpw240', '���ؿ�', 'f', '20-29', 0,'user240@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid241', 'adminpw241', '������', 'f', '20-29', 0,'user241@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid242', 'adminpw242', '������', 'm', '20-29', 0,'user242@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid243', 'adminpw243', '������', 'm', '20-29', 0,'user243@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid244', 'adminpw244', '����ȣ', 'f', '20-29', 0,'user244@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid245', 'adminpw245', '�ӹμ�', 'f', '20-29', 0,'user245@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid246', 'adminpw246', '������', 'f', '20-29', 0,'user246@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid247', 'adminpw247', '�ϼ���', 'm', '20-29', 0,'user247@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid248', 'adminpw248', '���¾�', 'f', '20-29', 0,'user248@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid249', 'adminpw249', '������', 'f', '20-29', 0,'user249@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid250', 'adminpw250', '������', 'f', '20-29', 0,'user250@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid251', 'adminpw251', '������', 'm', '20-29', 0,'user251@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid252', 'adminpw252', '����ȣ', 'm', '20-29', 0,'user252@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid253', 'adminpw253', '����ȣ', 'f', '20-29', 0,'user253@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid254', 'adminpw254', '�ۼ���', 'f', '20-29', 0,'user254@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid255', 'adminpw255', '������', 'f', '20-29', 0,'user255@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid256', 'adminpw256', '����ȣ', 'f', '20-29', 0,'user256@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid257', 'adminpw257', '����', 'm', '20-29', 0,'user257@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid258', 'adminpw258', '���ؼ�', 'm', '20-29', 0,'user258@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid259', 'adminpw259', '�Ͽ��', 'm', '20-29', 0,'user259@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid260', 'adminpw260', '�����', 'm', '20-29', 0,'user260@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid261', 'adminpw261', '������', 'm', '20-29', 0,'user261@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid262', 'adminpw262', '���Ѱ�', 'f', '20-29', 0,'user262@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid263', 'adminpw263', '������', 'm', '20-29', 0,'user263@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid264', 'adminpw264', '�缭��', 'm', '20-29', 0,'user264@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid265', 'adminpw265', '���Թ�', 'm', '20-29', 0,'user265@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid266', 'adminpw266', '������', 'f', '20-29', 0,'user266@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid267', 'adminpw267', '������', 'm', '20-29', 0,'user267@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid268', 'adminpw268', '������', 'f', '20-29', 0,'user268@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid269', 'adminpw269', '������', 'm', '20-29', 0,'user269@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid270', 'adminpw270', '���̾�', 'm', '20-29', 0,'user270@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid271', 'adminpw271', '���α�', 'f', '20-29', 0,'user271@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid272', 'adminpw272', '���¹�', 'm', '20-29', 0,'user272@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid273', 'adminpw273', '����ȣ', 'f', '20-29', 0,'user273@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid274', 'adminpw274', '�ӽ���', 'm', '20-29', 0,'user274@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid275', 'adminpw275', '�����', 'f', '20-29', 0,'user275@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid276', 'adminpw276', '������', 'f', '20-29', 0,'user276@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid277', 'adminpw277', '������', 'f', '20-29', 0,'user277@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid278', 'adminpw278', '�Ű���', 'm', '20-29', 0,'user278@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid279', 'adminpw279', '������', 'm', '20-29', 0,'user279@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid280', 'adminpw280', '�ż���', 'f', '20-29', 0,'user280@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid281', 'adminpw281', '�����', 'm', '20-29', 0,'user281@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid282', 'adminpw282', '���ؼ�', 'm', '20-29', 0,'user282@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid283', 'adminpw283', '������', 'f', '20-29', 0,'user283@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid284', 'adminpw284', '������', 'm', '20-29', 0,'user284@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid285', 'adminpw285', '������', 'm', '20-29', 0,'user285@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid286', 'adminpw286', '������', 'f', '20-29', 0,'user286@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid287', 'adminpw287', '������', 'm', '20-29', 0,'user287@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid288', 'adminpw288', '������', 'f', '20-29', 0,'user288@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid289', 'adminpw289', '���ؼ�', 'f', '20-29', 0,'user289@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid290', 'adminpw290', '��μ�', 'm', '20-29', 0,'user290@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid291', 'adminpw291', '������', 'f', '20-29', 0,'user291@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid292', 'adminpw292', '���ÿ�', 'f', '20-29', 0,'user292@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid293', 'adminpw293', '������', 'f', '20-29', 0,'user293@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid294', 'adminpw294', '��Թ�', 'm', '20-29', 0,'user294@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid295', 'adminpw295', '����ȣ', 'f', '20-29', 0,'user295@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid296', 'adminpw296', '������', 'm', '20-29', 0,'user296@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid297', 'adminpw297', '���ֿ�', 'm', '20-29', 0,'user297@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid298', 'adminpw298', '������', 'm', '20-29', 0,'user298@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid299', 'adminpw299', '������', 'm', '20-29', 0,'user299@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid300', 'adminpw300', '������', 'm', '20-29', 0,'user300@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid301', 'adminpw301', '���϶�', 'f', '20-29', 0,'user301@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid302', 'adminpw302', '������', 'm', '20-29', 0,'user302@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid303', 'adminpw303', '������', 'm', '20-29', 0,'user303@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid304', 'adminpw304', '������', 'm', '20-29', 0,'user304@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid305', 'adminpw305', '������', 'f', '20-29', 0,'user305@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid306', 'adminpw306', '������', 'f', '20-29', 0,'user306@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid307', 'adminpw307', '�ι���', 'm', '20-29', 0,'user307@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid308', 'adminpw308', '������', 'm', '20-29', 0,'user308@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid309', 'adminpw309', '������', 'f', '20-29', 0,'user309@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid310', 'adminpw310', '���ؿ�', 'm', '20-29', 0,'user310@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid311', 'adminpw311', '�����', 'm', '20-29', 0,'user311@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid312', 'adminpw312', '������', 'm', '20-29', 0,'user312@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid313', 'adminpw313', '�ǵ���', 'm', '20-29', 0,'user313@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid314', 'adminpw314', '������', 'f', '20-29', 0,'user314@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid315', 'adminpw315', '����', 'm', '20-29', 0,'user315@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid316', 'adminpw316', '������', 'm', '20-29', 0,'user316@meeteat.com',null, 1);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid317', 'adminpw317', '������', 'f', '20-29', 0,'user317@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid318', 'adminpw318', '������', 'f', '20-29', 0,'user318@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid319', 'adminpw319', '������', 'm', '20-29', 0,'user319@meeteat.com',null, 2);
INSERT INTO tb_user2 (USER_NO, USER_ID, USER_PW, USER_NICK, USER_GENDER, USER_AGE, USER_BLOCKCNT, USER_EMAIL, user_profileorigin, USER_GRADE)
 VALUES(tb_user2_seq.nextval, 'adminid3192', 'adminpw3192', '������', 'm', '20-29', 0,'user319@meeteat.com',null, 2);



--rollback;
commit;
SELECT * FROM tb_user2
ORDER BY user_no;

